# SCI
Asignatura de Sistemas de Control Inteligente
